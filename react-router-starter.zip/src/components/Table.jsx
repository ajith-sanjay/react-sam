import React from 'react';

const Table = (props) => {
  const [data, setData] = React.useState( [
{
  "Rank": "1",
  "Points": 12,
  "Name": "Alice R, Joseph",
  "Age": "25"
},
{
  "Rank": 2,
  "Points": 33,
  "Name": " Joseph A, Alice",
  "Age": "28"
},
{
  "Rank": 3,
  "Points": 10,
  "Name": "Volve Team",
  "Age": "55"
},
{
  "Rank": 4,
  "Points": 12,
  "Name": "Charles R, Sachin",
  "Age": "51"
},
{
  "Rank": 5,
  "Points": 1,
  "Name": "Williams R, David",
  "Age": "32"
},
{
  "Rank": 6,
  "Points": 34,
  "Name": "Edward R, Gun",
  "Age": "42"
},
{
  "Rank": 7,
  "Points": 51,
  "Name": "Sharon R, Reyon",
  "Age": "48"
},
{
  "Rank": 8,
  "Points": 1,
  "Name": "John h, Green",
  "Age": "25"
},
{
  "Rank": 9,
  "Points": 1,
  "Name": "Grace C, Smith",
  "Age": "29"
}

]);

  React.useEffect( () => {
      let loc = [...data], abc;

    if(props.sortBy !== 'Name'){
      abc = loc.sort( (a,b) => a[props.sortBy] - b[props.sortBy]);
      
    }
    else{
      abc = loc.sort(function(a, b){
        if(a.Name.toLowerCase() < b.Name.toLowerCase()) { return -1; }
        if(a.Name.toLowerCase() > b.Name.toLowerCase()) { return 1; }
        return 0;
    });
    }
    setData(abc);
  }, [props.sortBy]);
  return (<div>
    {data.map(v => <div>
      <span>{v.Rank}</span>&nbsp;&nbsp;
      <span>{v.Points}</span>&nbsp;&nbsp;    
      <span>{v.Name}</span>&nbsp;&nbsp;    
      <span>{v.Age}</span>&nbsp;&nbsp;    
    </div>)}
  </div>)
};

export default Table;
