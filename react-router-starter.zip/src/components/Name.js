import React from 'react';
import { Link, Route } from 'react-router-dom';
import Table from './Table';

const Name = ({ match }) => (
  <div>
    <Table sortBy = "Name"/>
    
  </div>
);

export default Name;
