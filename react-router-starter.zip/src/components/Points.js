import React from 'react';
import Table from './Table';

const Points = () => (
  <div>
    <Table sortBy = "Points"/>
    
  </div>
);

export default Points;
