import React from 'react';
import Table from './Table';

const Rank = () => (
  <div>
    <Table sortBy = "Rank"/>
    
  </div>
);

export default Rank;
