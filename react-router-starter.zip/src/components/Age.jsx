import React from 'react';
import Table from './Table';

const Age = () => (
  <div>
    <Table sortBy = "Age"/>
  </div>
);

export default Age;
