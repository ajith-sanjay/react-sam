import React from 'react';
import { render } from 'react-dom';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

import Points from './components/Points';
import Rank from './components/Rank';
import Name from './components/Name';
import Age from './components/Age';


const BasicExample = () => (
  <Router>
    <div>
      Leaderboard
      <ul>
        <li><Link to="/">Rank</Link></li>
        <li><Link to="/points">Points</Link></li>
        <li><Link to="/name">Name</Link></li>
        <li><Link to="/age">Age</Link></li>

      </ul>

      <hr />

      <Route exact path="/" component={Rank} />
      <Route path="/points" component={Points} />
      <Route path="/name" component={Name} />
      <Route path="/age" component={Age} />

    </div>
  </Router>
);

render(<BasicExample />, document.getElementById('root'));
